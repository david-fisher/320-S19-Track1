package posting;

public class post 
{
	String email;
	String postID;
	String text;
	
	int pointsForPost;
	
	public post(String email, String postID, String text) 
	{
		this.email = email;
		this.postID = postID;
		this.text = text;
		addPoints();
	}
	
	String getEmail() 
	{
		return email;
	}
	
	String getText() 
	{
		return text;
	}
	
	String getPostID()
	{
		return postID;
	}
	
	void addPoints() 
	{
		return;
	}
	
}
