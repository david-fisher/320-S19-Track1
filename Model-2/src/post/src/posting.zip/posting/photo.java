package posting;

public class photo {

}
