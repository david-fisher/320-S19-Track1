package posting;

public class comment extends post
{
	post associatedPostID;
	int pointsForComment;
	
	public comment(String email, String ID, String text, post associatedPostID) 
	{
		super(email, ID, text);
		this.associatedPostID = associatedPostID;
		super.pointsForPost = pointsForComment;
	}
	
	post getAssociatedPostID() 
	{
		return associatedPostID;
	}
	
	void addPoints() 
	{
		
		return;
	}
	
}
