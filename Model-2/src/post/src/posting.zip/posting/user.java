package posting;

public class user {

}
